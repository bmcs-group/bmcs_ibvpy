
_engine = None

def set_engine(e):
    _engine = e

def get_engine():
    _engine