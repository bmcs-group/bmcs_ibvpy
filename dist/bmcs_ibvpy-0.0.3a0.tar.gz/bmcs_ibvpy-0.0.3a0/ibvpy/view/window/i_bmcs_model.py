'''
Created on Mar 2, 2020

@author: rch
'''

from traits.api import Interface


class IBMCSModel(Interface):
    r'''
    '''
