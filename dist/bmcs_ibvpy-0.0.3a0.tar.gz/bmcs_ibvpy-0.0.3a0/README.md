
# Initial Boundary Value Problem Solver

exploting in inditial notation and Einstein 
summation rule available in Python
