

# 1D5 elements - zero thickness elements
from .fets1d52ulrh import FETS1D52ULRH
